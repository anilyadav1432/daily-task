
        const arrayDetails=[
                {
                    name: "Avinash Pandey",
                    age: "18", 
                    isBestFriend: "true", 
                    favouriteColors:["yellow","blue"], 
                    yellowFavourite:function(){
                            if(this.favouriteColors.includes("yellow"))
                            {
                                return "Yellow is my favourite colour";
                            }
                            else if(!this.favouriteColors.includes("yellow"))
                            {
                                return "Yellow is not my favourite colour";
                            }
                    }
                },
                {
                    name: "Ankur singh", 
                    age: "25",
                    isBestFriend: "false", 
                    favouriteColors:["purple","pink","white"], 
                    yellowFavourite:function(){
                        if(this.favouriteColors.includes("yellow"))
                        {
                            return "Yellow is my favourite colour";
                        }
                        else if(!this.favouriteColors.includes("yellow"))
                        {
                            return "Yellow is not my favourite colour";
                        }
                    }
                },
                {
                    name: "Arvind Yadav", 
                    age: "25", 
                    isBestFriend: "false", 
                    favouriteColors:["red","orange"], 
                    yellowFavourite:function(){
                        if(this.favouriteColors.includes("yellow"))
                        {
                            return "Yellow is my favourite colour";
                        }
                        else if(!this.favouriteColors.includes("yellow"))
                        {
                            return "Yellow is not my favourite colour";
                        }
                    }
                },
                {
                    name: "Diksha Mishra",
                    age: "21", 
                    isBestFriend: "true", 
                    favouriteColors:["yellow","green"], 
                    yellowFavourite:function(){
                        if(this.favouriteColors.includes("yellow"))
                        {
                            return "Yellow is my favourite colour";
                        }
                        else if(!this.favouriteColors.includes("yellow"))
                        {
                            return "Yellow is not my favourite colour";
                        }
                    }
                },
                {
                    name: "Anil Yadav", 
                    age: "22", 
                    isBestFriend: "true", 
                    favouriteColors:["skyblue","pink","green"], 
                    yellowFavourite:function(){
                        if(this.favouriteColors.includes("yellow"))
                        {
                            return "Yellow is my favourite colour";
                        }
                        else if(!this.favouriteColors.includes("yellow"))
                        {
                            return "Yellow is not my favourite colour";
                        }
                    }
                },
        ]
                var snn=1;
        document.write(`<div class="mainDiv"><table border="1"><tr><td>S.No.</td><td>Name</td><td>Age</td><td>BestFriend</td>`);
        var maxVal=arrayDetails[0].favouriteColors.length;
        for(var i=1; i < arrayDetails.length; i++)
        {
            var j = arrayDetails[i].favouriteColors.length;
            if(j > maxVal)
            {
                maxVal = j;
            }
        }

        for(var colorNo=1; colorNo<=maxVal;colorNo++)
        {
        document.write(`<td>FavouritesColour${colorNo}</td>`);
        }
        
        document.write(`<td>YellowFabourate</td></tr>`);
        for(var b=0;b<arrayDetails.length;b++)
        {
            document.write(`<tr><td>${snn}</td><td>${arrayDetails[b].name}</td><td>${arrayDetails[b].age}</td><td>${arrayDetails[b].isBestFriend}</td>`);
                for(var colorNo=0; colorNo<maxVal;colorNo++)
                {
                    if(arrayDetails[b].favouriteColors[colorNo]!=null)
                    {
                        document.write(`<td>${arrayDetails[b].favouriteColors[colorNo]}</td>`);
                    }
                    else
                    {
                        document.write(`<td> </td>`);
                    }
                }
            document.write(`<td>${arrayDetails[b].yellowFavourite()}</td></tr>`);
            snn++;
        }
        document.write(`</table></div>`);